# Real2Sim 方案与公开案例执行记录

日期：2026-09-27

## 已执行

- `test_checks.py`: 27/27 核心检查通过
- `tests/test_extended.py`: 8/8 扩展检查通过
- `run_examples.py --vision`: A-I 9 个案例全部退出码 0
- H100 xArm7/ACT 闭环：1800 steps，双相机各 1801 帧，60.03 s 视频
- T-block 任务指标：0/1，最小末段 MSE 约 0.01125，阈值 0.002

## 公开流程对应关系

1. COLMAP SfM/MVS：相机位姿、稀疏点和尺度恢复
   https://colmap.github.io/
2. Nerfstudio Splatfacto：Gaussian 外观训练和留出视角
   https://docs.nerf.studio/
3. Open3D TSDF：RGB-D 融合和网格生成
   https://www.open3d.org/html/tutorial/Advanced/rgbd_integration.html
4. MuJoCo MJCF：机器人、动力学和接触建模
   https://mujoco.readthedocs.io/en/latest/modeling.html
5. Hugging Face LeRobot ACT：视频、状态、动作格式和策略推理
   https://huggingface.co/docs/lerobot/main/index

## 运行边界

当前完整 xArm7 闭环使用作者提供的扫描资产。它证明了环境、渲染器、物理和策略接口可以运行，不证明我们自己的完整工作空间重建已经完成，也不证明仿真可以替代真机。

自己的完整场景仍需完整静态多视角 RGB/RGB-D、相机内外参、米制尺度，以及可选实例标签和注册深度。模板见 `workspace_capture_xarm_template.json`。
